#!/usr/bin/env node

const fetch = require('node-fetch');

const API_BASE = 'https://gruju-backend-5014424c95f2.herokuapp.com';

async function testCompletePendingFlow() {
    try {
        console.log('🧪 COMPLETE PENDING INVITATIONS FLOW TEST');
        console.log('='.repeat(50));
        
        // Step 1: Login as the test3 user (Charlie/host)
        console.log('\n1. LOGIN AS HOST USER...');
        const hostLoginResponse = await fetch(`${API_BASE}/api/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: 'jonathan.roberts006@hotmail.co.uk', password: 'test123' })
        });
        
        const hostLoginData = await hostLoginResponse.json();
        if (!hostLoginData.success) {
            console.log('❌ Host login failed');
            return;
        }
        console.log('✅ Host login successful');
        console.log('👤 Host user:', hostLoginData.user);
        const hostToken = hostLoginData.token;
        const hostUserId = hostLoginData.user.id;
        const hostUuid = hostLoginData.user.uuid;
        
        // Step 2: Login as Emilia (target user)
        console.log('\n2. LOGIN AS TARGET USER (EMILIA)...');
        const emiliaLoginResponse = await fetch(`${API_BASE}/api/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: 'roberts@example.com', password: 'test123' })
        });
        
        const emiliaLoginData = await emiliaLoginResponse.json();
        if (!emiliaLoginData.success) {
            console.log('❌ Emilia login failed');
            return;
        }
        console.log('✅ Emilia login successful');
        console.log('👤 Emilia user:', emiliaLoginData.user);
        const emiliaToken = emiliaLoginData.token;
        const emiliaUserId = emiliaLoginData.user.uuid; // Use UUID since ID is not in response
        const emiliaUuid = emiliaLoginData.user.uuid;
        
        // Step 3: Get children for both users
        console.log('\n3. GET CHILDREN FOR BOTH USERS...');
        
        const hostChildrenResponse = await fetch(`${API_BASE}/api/children`, {
            headers: { 'Authorization': `Bearer ${hostToken}` }
        });
        const hostChildrenData = await hostChildrenResponse.json();
        const hostChild = hostChildrenData.data[0];
        console.log('👶 Host child:', hostChild);
        
        const emiliaChildrenResponse = await fetch(`${API_BASE}/api/children`, {
            headers: { 'Authorization': `Bearer ${emiliaToken}` }
        });
        const emiliaChildrenData = await emiliaChildrenResponse.json();
        const emiliaChild = emiliaChildrenData.data[0];
        console.log('👶 Emilia child:', emiliaChild);
        
        if (!hostChild || !emiliaChild) {
            console.log('❌ Missing children data');
            return;
        }
        
        // Step 4: Create a test activity (scroll1) as the host
        console.log('\n4. CREATE TEST ACTIVITY "SCROLL1"...');
        
        const testActivityData = {
            name: 'scroll1',
            description: 'Test activity for pending invitations',
            start_date: '2025-01-15',
            end_date: '2025-01-15',
            start_time: '14:00',
            end_time: '16:00',
            location: 'Test Location',
            max_participants: 10,
            cost: 0,
            auto_notify_new_connections: false
        };
        
        const createActivityResponse = await fetch(`${API_BASE}/api/activities/${hostChild.uuid}`, {
            method: 'POST',
            headers: { 
                'Authorization': `Bearer ${hostToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(testActivityData)
        });
        
        if (!createActivityResponse.ok) {
            const errorText = await createActivityResponse.text();
            console.log('❌ Failed to create activity:', errorText);
            return;
        }
        
        const createActivityResult = await createActivityResponse.json();
        console.log('✅ Created test activity:', createActivityResult);
        const activityId = createActivityResult.data?.id || createActivityResult.id;
        const activityUuid = createActivityResult.data?.uuid || createActivityResult.uuid;
        
        // Step 5: Create a pending invitation for Emilia
        console.log('\n5. CREATE PENDING INVITATION FOR EMILIA...');
        
        const pendingKey = `pending-${emiliaUuid}`;
        console.log('🔑 Pending key:', pendingKey);
        
        const createPendingResponse = await fetch(`${API_BASE}/api/activities/${activityUuid}/pending-invitations`, {
            method: 'POST',
            headers: { 
                'Authorization': `Bearer ${hostToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                pending_connections: [pendingKey]
            })
        });
        
        if (!createPendingResponse.ok) {
            const errorText = await createPendingResponse.text();
            console.log('❌ Failed to create pending invitation:', errorText);
        } else {
            const pendingResult = await createPendingResponse.json();
            console.log('✅ Created pending invitation:', pendingResult);
        }
        
        // Step 6: Create a connection request from host to Emilia
        console.log('\n6. CREATE CONNECTION REQUEST FROM HOST TO EMILIA...');
        
        const connectionRequestData = {
            target_parent_id: emiliaUserId,
            child_uuid: hostChild.uuid,
            target_child_uuid: emiliaChild.uuid,
            message: 'Test connection request for pending invitations'
        };
        
        const createConnectionResponse = await fetch(`${API_BASE}/api/connections/request`, {
            method: 'POST',
            headers: { 
                'Authorization': `Bearer ${hostToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(connectionRequestData)
        });
        
        if (!createConnectionResponse.ok) {
            const errorText = await createConnectionResponse.text();
            console.log('❌ Failed to create connection request:', errorText);
        } else {
            const connectionResult = await createConnectionResponse.json();
            console.log('✅ Created connection request:', connectionResult);
        }
        
        // Step 7: Check Emilia's pending connection requests
        console.log('\n7. CHECK EMILIA\'S CONNECTION REQUESTS...');
        
        const emiliaRequestsResponse = await fetch(`${API_BASE}/api/connections/requests`, {
            headers: { 'Authorization': `Bearer ${emiliaToken}` }
        });
        const emiliaRequestsData = await emiliaRequestsResponse.json();
        console.log('📨 Emilia\'s connection requests:', emiliaRequestsData.data);
        
        const pendingRequest = emiliaRequestsData.data?.find(req => req.status === 'pending');
        
        if (!pendingRequest) {
            console.log('❌ No pending connection request found for Emilia');
            return;
        }
        
        console.log('🔍 Found pending request:', pendingRequest);
        
        // Step 8: Accept the connection request as Emilia
        console.log('\n8. ACCEPT CONNECTION REQUEST AS EMILIA...');
        
        const acceptResponse = await fetch(`${API_BASE}/api/connections/respond/${pendingRequest.request_uuid}`, {
            method: 'POST',
            headers: { 
                'Authorization': `Bearer ${emiliaToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ action: 'accept' })
        });
        
        if (!acceptResponse.ok) {
            const errorText = await acceptResponse.text();
            console.log('❌ Failed to accept connection request:', errorText);
            return;
        }
        
        const acceptResult = await acceptResponse.json();
        console.log('✅ Connection request accepted:', acceptResult);
        
        // Step 9: Wait for pending invitations processing
        console.log('\n9. WAITING FOR PENDING INVITATIONS PROCESSING...');
        await new Promise(resolve => setTimeout(resolve, 3000));
        
        // Step 10: Check if Emilia now has the invitation
        console.log('\n10. CHECK EMILIA\'S INVITATIONS...');
        
        const today = new Date();
        const oneYearLater = new Date();
        oneYearLater.setFullYear(oneYearLater.getFullYear() + 1);
        const startDate = today.toISOString().split('T')[0];
        const endDate = oneYearLater.toISOString().split('T')[0];
        
        const invitationsResponse = await fetch(`${API_BASE}/api/calendar/invitations?start=${startDate}&end=${endDate}`, {
            headers: { 'Authorization': `Bearer ${emiliaToken}` }
        });
        const invitationsData = await invitationsResponse.json();
        console.log('📬 Emilia\'s invitations after connection acceptance:', invitationsData.data);
        
        const scroll1Invitation = invitationsData.data?.find(inv => 
            inv.activity_name && inv.activity_name.toLowerCase().includes('scroll1')
        );
        
        // Step 11: Results and diagnosis
        console.log('\n' + '='.repeat(50));
        console.log('🏥 DIAGNOSIS RESULTS');
        console.log('='.repeat(50));
        
        if (scroll1Invitation) {
            console.log('🎉 SUCCESS! Pending invitations system is working correctly');
            console.log('✅ Emilia received the scroll1 invitation:', scroll1Invitation);
            
            console.log('\n📱 EMILIA SHOULD NOW SEE:');
            console.log('1. Login as roberts@example.com');
            console.log('2. Go to Children screen');
            console.log('3. Check pending invitations for Emilia');
            console.log('4. Should see invitation for "scroll1" activity');
            
        } else {
            console.log('❌ FAILED! Pending invitations system is not working');
            console.log('🔍 ROOT CAUSE ANALYSIS:');
            
            console.log('\n📋 Check these backend components:');
            console.log('1. processPendingInvitations() function in postgres-backend.js');
            console.log('2. Connection acceptance endpoint calling processPendingInvitations');
            console.log('3. pending_activity_invitations table structure');
            console.log('4. Activity invitation creation logic');
            
            console.log('\n🔧 DEBUGGING STEPS:');
            console.log('1. Check backend logs during connection acceptance');
            console.log('2. Verify pending_activity_invitations table has the data');
            console.log('3. Ensure processPendingInvitations is being called');
            console.log('4. Check if invitations are being created but filtered out');
        }
        
        console.log('\n📊 SUMMARY:');
        console.log(`- Host User: ${hostLoginData.user.email} (UUID: ${hostUuid})`);
        console.log(`- Target User: ${emiliaLoginData.user.email} (UUID: ${emiliaUuid})`);
        console.log(`- Activity Created: ${activityId ? '✅' : '❌'}`);
        console.log(`- Pending Invitation Created: ${createPendingResponse.ok ? '✅' : '❌'}`);
        console.log(`- Connection Request Created: ${createConnectionResponse.ok ? '✅' : '❌'}`);
        console.log(`- Connection Accepted: ${acceptResponse.ok ? '✅' : '❌'}`);
        console.log(`- Final Invitation Exists: ${scroll1Invitation ? '✅' : '❌'}`);
        
        if (!scroll1Invitation) {
            console.log('\n🔧 MANUAL FIX - CREATE INVITATION DIRECTLY:');
            
            const manualInviteResponse = await fetch(`${API_BASE}/api/activities/${activityUuid}/invite`, {
                method: 'POST',
                headers: { 
                    'Authorization': `Bearer ${hostToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    invited_child_id: emiliaChild.id,
                    message: 'Manual invitation for scroll1 activity'
                })
            });
            
            if (manualInviteResponse.ok) {
                const manualResult = await manualInviteResponse.json();
                console.log('✅ Manual invitation created successfully:', manualResult);
                console.log('📱 Emilia should now see the invitation in her app');
            } else {
                const errorText = await manualInviteResponse.text();
                console.log('❌ Manual invitation failed:', errorText);
            }
        }
        
    } catch (error) {
        console.error('❌ Test error:', error.message);
        console.error('Stack trace:', error.stack);
    }
}

testCompletePendingFlow();